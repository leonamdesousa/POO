public class Funcionario {
    // Questão 1:
    private String nome;
    private int identificador;

    // Construtor com nome opcional
    public Funcionario(String nome) {
        this.nome = nome;
        this.identificador = gerarIdentificadorUnico();
    }

    // Construtor sem argumentos (para caso de nome não fornecido)
    public Funcionario() {
        this.nome = "Funcionário sem nome";
        this.identificador = gerarIdentificadorUnico();
    }
    // Questão 2:
    // Getter para o nome
    public String getNome() {
        return nome;
    }
    //Questão 3:
    // Setter para o nome
    public void setNome(String nome) {
        this.nome = nome;
    }
    // questão 5:
    // Getter para o identificador
    public int getIdentificador() {
        return identificador;
    }

    // Método para gerar um identificador único
    private static int proximoIdentificador = 1;
    private static int gerarIdentificadorUnico() {
        return proximoIdentificador++;
    }
}