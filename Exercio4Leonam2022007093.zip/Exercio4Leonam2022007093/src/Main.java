// ALUNO: LEONAM DE SOUSA SILVA.
// MÁTRICULA: 2022007093.
public class Main{
    public static void main(String[] args){
        //
        Funcionario funcionario1 = new Funcionario("João");
        Funcionario funcionario2 = new Funcionario("marcos");

        System.out.println("Fucionário 1: " + funcionario1.getNome() + "ID:" + funcionario1.getIdentificador());
        System.out.println("Fucionário 2: " + funcionario2.getNome() + "ID:" + funcionario2.getIdentificador());

        funcionario1.setNome("felipe");
        System.out.println("Novo nome do Fucionário 1: " +funcionario1.getNome());
    }
}