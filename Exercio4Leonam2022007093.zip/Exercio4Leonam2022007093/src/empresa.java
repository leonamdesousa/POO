public class empresa {
    //Questão 6:
    private String nome;
    private String endereço;

    //Construtor
    public empresa(String nome, String endereço) {
        this.nome = nome;
        this.endereço = endereço;
    }
    //Getter para o nome
    public String getNome(){
        return nome;
    }
    //Setter para o nome
    public void setNome(String nome){
        this.nome = nome;
    }
    //Getter para o endereço
    public String getEndereço(){
        return endereço;
    }
    //Setter para o endereço
    public void setEndereço(String endereço){
        this.endereço = endereço;
    }
}
