public class Contapoupanca extends Conta {
    public Contapoupanca(double saldo) {
        super(saldo);
    }

    @Override
    public void atualiza() {
        saldo += saldo * 0.03; // Por exemplo, atualização de 3% para Conta Poupança
    }
}
