public class Main {
    public static void main(String[] args) {
        Contapoupanca contaPoupanca = new Contapoupanca(1000.0);
        System.out.println("Saldo antes da atualização: " + contaPoupanca.getSaldo());
        contaPoupanca.atualiza();
        System.out.println("Saldo após a atualização: " + contaPoupanca.getSaldo());
    }
}